
public abstract class Person {
     public abstract void gt_details();
     public abstract void modify();
     public abstract void set_details();
}
